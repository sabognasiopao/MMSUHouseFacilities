<html>
    <head>
        <title>MMSU-Dorm Finder</title>
        <link rel="stylesheet" href="/css/style.css" type="text/css">
        <body>
            <div class="topnav" id="myTopnav">
                <a href="dashboard" class="active">Home</a>
                <a href="#news">CONTACT</a>
                <a href="#contact">ABOUT US</a>
                <a href="dorm">LIST OF DORMS</a>
            </div>
            <div class="header">
                <h1>HOUSING FACILITIES - ON CAMPUS</h1>
            </div>
            <div class="dorm_details_con">
                <div class="dorm_name">
                    <h2>STUDENT RESIDENCE HALL</h2>
                </div>

                <div class="dorm_img">
                    <img src="" alt="">
                </div>

                <div class="dorm_details">
                    <h3>Owner</h3>
                    <h3>Location</h3>
                    <h3>Contact</h3>

                    <h3>Rental Fee</h3>
                    <h3>Amenities</h3>

                    <h3>Terms of Payment</h3>
                    <h3>Available Space</h3>
                </div>

                <div class="dorm_info">
                    <h3>Henry Tabaniag</h3>
                    <h3>#16-S Quiling Sur - NGZ, City of Batac, Ilocos Norte</h3>
                    <h3>0995-253-2991</h3>

                    <h3>Php 1500 / month</h3>
                    <h3>Amenities</h3>

                    <h3>2 months advanced payment</h3>
                    <h3>5 Bedspace Available</h3>
                </div>
            </div>
        </body>
    </head>
</html><?php /**PATH C:\Users\Dreii\Documents\laravel\DormFinder\resources\views/oncampus.blade.php ENDPATH**/ ?>
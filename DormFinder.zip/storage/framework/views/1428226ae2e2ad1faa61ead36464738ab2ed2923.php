<div class="topnav" id="myTopnav">
  <a href="#home" class="active">Home</a>
  <a href="#news">CONTACT</a>
  <a href="#contact">ABOUT US</a>
  <a href="#about">LIST OF DORMS</a>
</div><?php /**PATH C:\Users\Dreii\Documents\laravel\DormFinder\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>
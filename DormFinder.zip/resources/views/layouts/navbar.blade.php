<div class="topnav" id="myTopnav">
  <a href="#home" class="active">Home</a>
  <a href="#news">CONTACT</a>
  <a href="#contact">ABOUT US</a>
  <a href="#about">LIST OF DORMS</a>
</div>